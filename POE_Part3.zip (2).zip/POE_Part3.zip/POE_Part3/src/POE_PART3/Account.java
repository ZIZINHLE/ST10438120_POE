
package POE_PART3;


public class Account 
{
    private String username;
    private String Firstname;
    private String Lastname;
    private String Password;
   
    public Account(String Username,String Password, String Firstname, String Lastname)
    {
      this.username = Username;  
      this.Password = Password;
      this.Firstname = Firstname;
      this.Lastname = Lastname;
    }
    public void setUsername(String Username)
    {
        this.username = Username;
    }
    public String getUsername()
    {
        return this.username;
    }
    public void setPassword(String Password)
    {
        this.Password = Password;
    }
    public String getPasword()
    {
        return this.Password;
    }
    public void setFirstname(String Firstname)
    {
        this.Firstname = Firstname;
    }
    public String getFirstname()
    {
        return this.Firstname;
    }
    public void setLastname(String Lastname)
    {
        this.Lastname= Lastname;
    }
    public String getLastname()
    {
        return this.Lastname;
    }   
}
