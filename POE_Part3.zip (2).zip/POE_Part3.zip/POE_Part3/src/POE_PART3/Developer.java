package POE_PART3;

public class Developer {

    private String firstName;
    private String lastName;

    public Developer(String FirstName, String LastName) {
        this.firstName = FirstName;
        this.lastName = LastName;
    }

    public void SetFirstName(String FirstName) {
        this.firstName = FirstName;
    }

    public void SetLastName(String LastName) {
        this.lastName = LastName;
    }

    public String GetFirstName() {
        return this.firstName;
    }

    public String GetLastName() {
        return this.lastName;
    }
}
