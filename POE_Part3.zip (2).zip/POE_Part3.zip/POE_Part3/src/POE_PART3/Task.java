
package POE_PART3;
import javax.swing.JOptionPane;

public class Task 
{
   private String TaskName;
   private int TaskNumber;
   private String TaskDescription;
   private String DevFirstName;
   private String DevLastName;
   private int TaskDuration;
   private String TaskID;
   private String TaskStatus;

   public void SetTaskName(String TaskName)
   {
       this.TaskName = TaskName;
   }
   public String GetTaskName()
   {
       return this.TaskName;
   }
   
    public void SetTaskNumber(int TaskNumber)
   {
       this.TaskNumber = TaskNumber;
   }
   public int GetTaskNumber()
   {
       return this.TaskNumber;
   }
   
   public void SetTaskDescription(String TaskDescription)
   {
       this.TaskDescription = TaskDescription;
   }
   public String GetTaskDescription()
   {
       return this.TaskDescription;
   } 
    public void SetTaskDuration(int TaskDuration)
   {
       this.TaskDuration = TaskDuration;
   }
   public int GetTaskDuration()
   {
       return TaskDuration;
   }
   
   public void SetTaskID(String TaskID)
   {
       this.TaskID = TaskID;
   }
   public String GetTaskID()
   {
       return this.TaskID;
   }
   
   public void SetTaskStatus(String TaskStatus)
   {
       this.TaskStatus = TaskStatus;
   }
   public String GetTaskStatus()
   {
       return this.TaskStatus;
   }
   
    public boolean checkTaskDescription(String TaskDescription)
    {
        if(TaskDescription.length()> 50)
        {
            return false;
        }
       
        return true;
    }
    public String createTaskID(String TaskName,int TaskNumber, String DevFirstName, String DevLastName)
    {
        Developer Details = new Developer(DevFirstName,DevLastName);
        DevFirstName = (String)Details.GetFirstName();
        String DevLastLetters = DevFirstName.substring(DevFirstName.length() - 3,DevFirstName.length());
        
        
        String TaskLetters = TaskName.substring(0, 2);
        
        return TaskLetters+":"+TaskNumber+":"+DevLastLetters;
    }
    
    public String printTaskDetails(String TaskStatus, Developer Details,int TaskNumber, String TaskName, 
            String TaskDescription, String TaskID,int TaskDuration)
    {
       
        return "Task Status: "+TaskStatus+"\n"+"Developer: "+Details.GetFirstName()+" "+Details.GetLastName()+"\n"+"Task Number: "
                +TaskNumber+"\n"+"Task Name: "+TaskName+"\n"+"Task Description: "+TaskDescription+
                "\n"+"Task ID: "+TaskID+"\n"+"Task Duration: "+TaskDuration;
    }
    int TotalNumberOfTasks = 0;
    public int returnTotalHours(int TaskDuration)
    {
        return TotalNumberOfTasks+=TaskDuration;
    }
    
}