
package POE_PART3;
import javax.swing.JOptionPane;
public class Login 
{
    
    static Account NewAccount;
    static boolean LoginDetailsOkay = false;
    static boolean RegDetailsOkay = false;
    static String[] Developers;
    static String[] TaskNames;
    static String[] TaskID;
    static int[] TaskDurations;
    static String[] Status;
    
    public static void main(String[] args) 
    {
                System.out.println();
                String Username;
                String Password;
                String Firstname;
                String Lastname;
                // Registration 
                JOptionPane.showMessageDialog(null, "Click OK to proceed to Registration");
                Firstname = JOptionPane.showInputDialog("Please enter your First Name: ");
                Lastname = JOptionPane.showInputDialog("Please enter your Last Name: ");
                Username = JOptionPane.showInputDialog("Please create a new Username: ");
                Password = JOptionPane.showInputDialog("Please create a new password: ");       
                JOptionPane.showMessageDialog(null, registerUser(Username,Password,Firstname,Lastname));
                
                while(RegDetailsOkay == false)
                {
                   Username = JOptionPane.showInputDialog("Please create a new Username: ");
                   Password = JOptionPane.showInputDialog("Please create a new password: "); 
                   JOptionPane.showMessageDialog(null, registerUser(Username,Password,Firstname,Lastname));
                }
                
                //Log in 
                JOptionPane.showMessageDialog(null,"Click OK to Login to your account");
                Username = JOptionPane.showInputDialog("Please Enter your Username: ");
                Password = JOptionPane.showInputDialog("Please Enter Your Password: ");
                Firstname = NewAccount.getFirstname();
                Lastname = NewAccount.getLastname();
               JOptionPane.showMessageDialog(null,returnLoginStatus(Username,Password,Firstname,Lastname));
               
            while(LoginDetailsOkay == false)
            {
               Username = JOptionPane.showInputDialog("Please Enter your Username: ");
               Password = JOptionPane.showInputDialog("Please Enter Your Password: ");
               Firstname = NewAccount.getFirstname();
               Lastname = NewAccount.getLastname(); 
               JOptionPane.showMessageDialog(null,returnLoginStatus(Username,Password,Firstname,Lastname));

            }
                int Choice;
                
                do
                {
                    Choice = Menu();
                    switch(Choice)
                    {
                        case 1:AddTask();
                        break;
                        case 2: SubMenu();
                            break;
                        case 3:
                            break;
                        default: JOptionPane.showMessageDialog(null,"Wrong choice, please choose the options from the menu");
                            break;
                    }
                }
                while(Choice!=3);
                
    }
    public static int Menu()
    {
        int Choice = Integer.parseInt(JOptionPane.showInputDialog("Please Choose an option below:\n1. Add tasks\n2. Show Report\n3. Quit"));
        return Choice;
    }
    public static void SubMenu()
    {
        int SubMenuChoice = Integer.parseInt(JOptionPane.showInputDialog(
                    "Please select an option: \n1. Display finished Tasks\n2. Display longest duration task\n3. Search Task\n4. Search Developer\n5. Delete Task\n6. Dispaly All Tasks"));
            switch (SubMenuChoice) 
            {
                case 1:
                       DoneTaskDetails();
                       break;
                case 2: LongestDurationDetails();
                        break;
                case 3: SearchTaskName();
                        break;
                case 4:SearchDeveloperTasks();
                       break;
                case 5: DeleteTask();
                        break;
                case 6: DisplayAllDetails();
                             break;
                default: JOptionPane.showMessageDialog(null,"Wrong choice, please choose the options from the menu");
                        break;
             }
    }
    public static void AddTask()
    {
        int NumTasks = Integer.parseInt(JOptionPane.showInputDialog("Please Enter the number of tasks you want to add: "));
        
        Developers = new String[NumTasks];
        TaskNames= new String[NumTasks];
        TaskID = new String[NumTasks];
        TaskDurations = new int[NumTasks];
        Status = new String[NumTasks];
        
        Task NewTask = new Task();
        
        Developer Dev;
        int TaskNumber;
        String TaskName;
        String TaskDescription;
        String DevFirstname;
        String DevLastname;
        int TaskDuration;
        String TaskStatus;
        int TotalDuration = 0;
        for (int i = 0; i < NumTasks; i++)
        {
            TaskNumber = i;
           
            TaskName = JOptionPane.showInputDialog("Please Enter the task name: ");
            NewTask.SetTaskName(TaskName);
            TaskDescription = JOptionPane.showInputDialog("Please Enter the task Description: ");
            
            while(NewTask.checkTaskDescription(TaskDescription) == false)
             {
                 JOptionPane.showMessageDialog(null,"Please enter a task description of less than 50 characters");
               TaskDescription = JOptionPane.showInputDialog("Please Enter the task Description: ");
             }
            NewTask.SetTaskDescription(TaskDescription);
            DevFirstname = JOptionPane.showInputDialog("Please Enter the Developer's First Name: ");
           
            DevLastname = JOptionPane.showInputDialog("Please Enter Developer's Last Name: ");
           
            TaskDuration = Integer.parseInt(JOptionPane.showInputDialog("Please Enter the duration of the task in hours: "));
            NewTask.SetTaskDuration(TaskDuration);
            TotalDuration += TaskDuration;
            TaskStatus = JOptionPane.showInputDialog("Please enter one of the Task Status below: \nTo do \nDone \nDoing");
            String MyStatus = TaskStatus.toLowerCase();
            while(!(MyStatus.equals("to do")|| MyStatus.equals("done")
                    || MyStatus.equals("doing")))
            {
               TaskStatus = JOptionPane.showInputDialog("Please enter one of the Task Status below: \nTo do \nDone \nDoing");
               MyStatus = TaskStatus.toLowerCase();
            }
            NewTask.SetTaskStatus(TaskStatus);
            NewTask.SetTaskID(NewTask.createTaskID(TaskName, TaskNumber, DevFirstname, DevLastname).toUpperCase());
            Dev = new Developer(DevFirstname, DevLastname);
            JOptionPane.showMessageDialog(null,"Task Successfully capture!");
           JOptionPane.showMessageDialog(null, NewTask.printTaskDetails(TaskStatus, Dev,TaskNumber ,TaskName, TaskDescription, 
                   NewTask.GetTaskID(), TaskDuration));
           
           //Populating Arrays
           Developers[i] = Dev.GetFirstName()+" "+Dev.GetLastName();
           TaskNames[i] = TaskName;
           TaskID[i] = NewTask.GetTaskID();
           TaskDurations[i] = TaskDuration;
           Status[i] = TaskStatus;
        }
        
        JOptionPane.showMessageDialog(null, "The tasks will take "+TotalDuration+" hours to be completed");
    }
    
    
  public static boolean checkUserName(String Username)
  {
        return Username.contains("_")&& Username.length()<=5;
        
  }
    
public static boolean checkPasswordComplexity(String Password)
 {
         boolean hasDigit = false;
         boolean hasEightCharacters = false;
         boolean hasSpecialCharacters = false;
         boolean hasCapital = false;
         char[] MyChars = Password.toCharArray();
        
        if(Password.length() >= 8)
        {
            hasEightCharacters = true;
        }
        for (int i = 0; i < MyChars.length; i++) 
        {
            if(Character.isDigit(MyChars[i]))
            {
                hasDigit = true;
            }
            if(Character.isUpperCase(MyChars[i]))
            {
                hasCapital = true;
            }
            if(!Character.isDigit(MyChars[i])&& !Character.isWhitespace(MyChars[i])
                    && !Character.isLetter(MyChars[i]))
            {
                hasSpecialCharacters = true;
            }
           
        }
      
       return hasDigit == true && hasCapital == true && hasSpecialCharacters == true 
               && hasEightCharacters == true;
            
 }
        
     public static String registerUser(String Username, String Password, String Firstname, String Lastname)
     {
        if(checkUserName(Username)== true && checkPasswordComplexity(Password) == true )
        {
            NewAccount = new Account(Username, Password,Firstname,Lastname);
            RegDetailsOkay = true;
            return """
                   Username Successfully captured! 
                   Password successfully captured!""";
        }
        else if(checkUserName(Username) == false && checkPasswordComplexity(Password)== false)
        {
             return """
                   Username and Password are not correctly formatted, please ensure your username contains an underscore and is no more than 5 characters in length.
                    Please ensure that the password contains at least 8 characters, a capital letter, a number and a special character""";
        
        }
        else if(checkUserName(Username)== false)
        {
            return "Username is not correctly formatted,"+ 
                   "please ensure your username contains an underscore and is no more than 5 characters in length.";
        }
        else  
        {
            return "Your Password is not correctly formatted, "
                    + "please ensure that the passowrd contains at least 8 characters, a capital letter, a number,"
                    + "and a special character";
        }
    }
     
     public static boolean LoginUser(String Username, String Password)
     {
         if( NewAccount.getUsername().equals(Username) && NewAccount.getPasword().equals(Password))
         {
             LoginDetailsOkay = true;
             return true;
         }
         else
         {
             return false;
         }
     }
     
     public static String returnLoginStatus(String Username, String Password, String Firstname, String Lastname)
     {
         if(LoginUser(Username,Password) == true)
         {
             return "Welcome to EasyKaban ";
         }
         else
         {
             return "Username or Password incorrect, please try again";  
         }
     }
     
     //Part 3 Mehtods
      public static void DoneTaskDetails()
       { 
          String Cur, Display = "";
          
           for (int i = 0; i < Status.length; i++) 
           {
               Cur = Status[i];
               
               if(Cur.toLowerCase().equals("done"))
               {
                   Display += "\n\nDeveloper: "+Developers[i]+"\nTask Name: "+TaskNames[i]+"\nTask Duration: "+TaskDurations[i]; 
               }
           }
            JOptionPane.showMessageDialog(null,Display);
       }
       
       
       public static void LongestDurationDetails()
       { 
          int Cur;
          int Max = -9999;
          int MaxSub =  -1;
          
           for (int i = 0; i < Status.length; i++) 
           {
               Cur = TaskDurations[i];
               
               if(Cur >= Max)
               {
                   Max = Cur;
                   MaxSub = i;
               }
           }
            JOptionPane.showMessageDialog(null,"Developer: "+Developers[MaxSub]+"\nTask Duration: "+TaskDurations[MaxSub]);
       }
       public static void SearchTaskName()
       {
           String NameToSearch = JOptionPane.showInputDialog("Please enter the task name you want to search");
           String Found = "no";
           int FoundSub = -1;
           String Cur;
           for (int i = 0; i < TaskNames.length; i++)
           {
               Cur = TaskNames[i].toLowerCase();
               NameToSearch = NameToSearch.toLowerCase();
               if(NameToSearch.equals(Cur))
               {
                  Found = "Yes";
                  FoundSub =i;
                  break;
               }
           }
           if(Found.equals("Yes"))
           {
               JOptionPane.showMessageDialog(null,"\nTask Name: "+TaskNames[FoundSub]+"\nTask Developer: "+Developers[FoundSub]
                       +"\nTask Status: "+Status[FoundSub]);
           }
           else
           {
               JOptionPane.showMessageDialog(null, "Sorry we can't find the task you are looking for");
           } 
       }
       
       public static void SearchDeveloperTasks()
       {
           String NameToSearch = JOptionPane.showInputDialog("Please enter the names of the developer:");
           String Found = "no";
           String Cur;
           String Display = "";
           for (int i = 0; i < Developers.length; i++)
           {
               Cur = Developers[i].toLowerCase();
               NameToSearch = NameToSearch.toLowerCase();
               if(NameToSearch.equals(Cur))
               {
                  Found = "Yes";
                  Display += "\n\nTask Name: "+TaskNames[i]+"\nTask Status: "+Status[i];
               }
           }
           if(Found.equals("Yes"))
           { 
               JOptionPane.showMessageDialog(null,"Tasks done by "+NameToSearch+":" +Display);
           }
           else
           {
               JOptionPane.showMessageDialog(null, "Sorry we can't find the Developer you are looking for");
           } 
       }
       public static void DeleteTask()
       {
           String NameToSearch = JOptionPane.showInputDialog("Please enter the name of the task you want to delete: ");
           String Found = "no";
           int DeletedIndex = -1;
           String CurTask;
           int Size = TaskNames.length-1;
           
           for (int i = 0; i < TaskNames.length; i++)
           {
               CurTask = TaskNames[i].toLowerCase();
               
               NameToSearch = NameToSearch.toLowerCase();
               if(NameToSearch.equals(CurTask))
               {
                   Found = "Yes";
                   DeletedIndex = i;
                   break;
               }
            
           }
           if(Found.equals("Yes"))
           {
               for (int j = DeletedIndex; j < Size; j++)
               {
                   TaskNames[j] = TaskNames[j+1];
                   Developers[j] = Developers[j+1];
                   TaskDurations[j] = TaskDurations[j+1];
                   TaskID[j] = TaskID[j+1];
                   Status[j] = Status[j+1];
               }
               TaskNames[TaskNames.length -1] = null;
               Developers[Developers.length-1] = null;
               TaskDurations[TaskDurations.length-1] = 0;
               TaskID[TaskID.length-1] = null;
               Status[Status.length-1] = null;
               JOptionPane.showMessageDialog(null, "The task has been sucessfully deleted!");
           }
           else
           {
               JOptionPane.showMessageDialog(null, "Sorry the task you want to delete is not in the array");
           }
       }
       public static void DisplayAllDetails()
       {
           String DisplayTaskDetails = "";
           for (int i = 0; i < TaskNames.length; i++)
           {
               if(Developers[i]!= null)
               {
                  DisplayTaskDetails += "\n\nDeveloper: "+Developers[i]+"\nTask ID: "+TaskID[i]+"\nTask Name: "+TaskNames[i]
                       +"\nTask Duration: "+TaskDurations[i]+"\nTask Status: "+Status[i];
               }
           }
           JOptionPane.showMessageDialog(null,"The details of all Tasks Created:" + DisplayTaskDetails);
       }
}
    

