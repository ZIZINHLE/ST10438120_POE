
package POE_PART3;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class Login.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Login.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Menu method, of class Login.
     */
    @Test
    public void testMenu() {
        System.out.println("Menu");
        int expResult = 0;
        int result = Login.Menu();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SubMenu method, of class Login.
     */
    @Test
    public void testSubMenu() {
        System.out.println("SubMenu");
        Login.SubMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of AddTask method, of class Login.
     */
    @Test
    public void testAddTask() {
        System.out.println("AddTask");
        Login.AddTask();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String Username = "";
        boolean expResult = false;
        boolean result = Login.checkUserName(Username);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String Password = "";
        boolean expResult = false;
        boolean result = Login.checkPasswordComplexity(Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String Username = "";
        String Password = "";
        String Firstname = "";
        String Lastname = "";
        String expResult = "";
        String result = Login.registerUser(Username, Password, Firstname, Lastname);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of LoginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("LoginUser");
        String Username = "";
        String Password = "";
        boolean expResult = false;
        boolean result = Login.LoginUser(Username, Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        String Username = "";
        String Password = "";
        String Firstname = "";
        String Lastname = "";
        String expResult = "";
        String result = Login.returnLoginStatus(Username, Password, Firstname, Lastname);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of DoneTaskDetails method, of class Login.
     */
    @Test
    public void testDoneTaskDetails() {
        System.out.println("DoneTaskDetails");
        Login.DoneTaskDetails();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of LongestDurationDetails method, of class Login.
     */
    @Test
    public void testLongestDurationDetails() {
        System.out.println("LongestDurationDetails");
        Login.LongestDurationDetails();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SearchTaskName method, of class Login.
     */
    @Test
    public void testSearchTaskName() {
        System.out.println("SearchTaskName");
        Login.SearchTaskName();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SearchDeveloperTasks method, of class Login.
     */
    @Test
    public void testSearchDeveloperTasks() {
        System.out.println("SearchDeveloperTasks");
        Login.SearchDeveloperTasks();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of DeleteTask method, of class Login.
     */
    @Test
    public void testDeleteTask() {
        System.out.println("DeleteTask");
        Login.DeleteTask();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of DisplayAllDetails method, of class Login.
     */
    @Test
    public void testDisplayAllDetails() {
        System.out.println("DisplayAllDetails");
        Login.DisplayAllDetails();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
