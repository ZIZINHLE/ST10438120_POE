
package POE_PART3;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class DeveloperTest {
    
    public DeveloperTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of SetFirstName method, of class Developer.
     */
    @Test
    public void testSetFirstName() {
        System.out.println("SetFirstName");
        String FirstName = "";
        Developer instance = null;
        instance.SetFirstName(FirstName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetLastName method, of class Developer.
     */
    @Test
    public void testSetLastName() {
        System.out.println("SetLastName");
        String LastName = "";
        Developer instance = null;
        instance.SetLastName(LastName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetFirstName method, of class Developer.
     */
    @Test
    public void testGetFirstName() {
        System.out.println("GetFirstName");
        Developer instance = null;
        String expResult = "";
        String result = instance.GetFirstName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetLastName method, of class Developer.
     */
    @Test
    public void testGetLastName() {
        System.out.println("GetLastName");
        Developer instance = null;
        String expResult = "";
        String result = instance.GetLastName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
